import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:forja/main.dart';
import 'package:forja/pages/personalizacao.dart';

void main() {
  testWidgets('Abertura navega pelas três telas existentes', (tester) async {
    await tester.pumpWidget(const ForjaApp());
    await tester.pumpAndSettle();
    expect(find.text('CRIE SEU\nPERSONAGEM'), findsOneWidget);
    final start = find.text('COMEÇAR');
    await tester.ensureVisible(start);
    await tester.tap(start);
    await tester.pumpAndSettle();
    expect(find.text('ESCOLHA SUA CLASSE'), findsOneWidget);

    await tester.tap(find.text('Mago'));
    await tester.pumpAndSettle();
    expect(
      find.ancestor(
        of: find.text('Mago'),
        matching: find.byWidgetPredicate(
          (widget) => widget is Semantics && widget.properties.selected == true,
        ),
      ),
      findsOneWidget,
    );

    await tester.tap(find.text('PRÓXIMO  ›'));
    await tester.pumpAndSettle();
    expect(find.text('ESCOLHA SEU GÊNERO'), findsOneWidget);
    await tester.tap(find.text('Feminino'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('PRÓXIMO ›'));
    await tester.pumpAndSettle();
    expect(find.text('APARÊNCIA'), findsOneWidget);
    expect(tester.takeException(), isNull);
  });

  testWidgets('Login informa que a função ainda está em desenvolvimento', (tester) async {
    await tester.pumpWidget(const ForjaApp());
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('LOGIN'));
    await tester.tap(find.text('LOGIN'));
    await tester.pumpAndSettle();
    expect(find.text('Tela de login em desenvolvimento.'), findsOneWidget);
  });

  testWidgets('Telas cabem em celular pequeno com texto ampliado', (tester) async {
    tester.view.physicalSize = const Size(320, 568);
    tester.view.devicePixelRatio = 1;
    addTearDown(tester.view.resetPhysicalSize);
    addTearDown(tester.view.resetDevicePixelRatio);
    tester.platformDispatcher.textScaleFactorTestValue = 1.3;
    addTearDown(tester.platformDispatcher.clearTextScaleFactorTestValue);

    await tester.pumpWidget(const ForjaApp());
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.ensureVisible(find.text('COMEÇAR'));
    await tester.tap(find.text('COMEÇAR'));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('PRÓXIMO  ›'));
    await tester.pumpAndSettle();
    expect(tester.takeException(), isNull);
    await tester.tap(find.text('PRÓXIMO ›'));
    await tester.pumpAndSettle();
    expect(find.byType(AparenciaScreen), findsOneWidget);
    expect(tester.takeException(), isNull);
  });
}
