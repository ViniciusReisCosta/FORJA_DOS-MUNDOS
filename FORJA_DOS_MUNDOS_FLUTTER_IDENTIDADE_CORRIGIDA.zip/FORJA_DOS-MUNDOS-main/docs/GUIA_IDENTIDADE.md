# Identidade visual oficial — Forja dos Mundos Mobile

## Regra principal

O protótipo roxo enviado como referência serve para **fluxo e composição de telas**, não para definir a marca.
A interface da Forja deve seguir o mesmo universo visual do site e do documento oficial mobile.

### Paleta oficial

| Token | Hex | Uso |
|---|---|---|
| Preto Abissal | `#0B0E14` | fundo principal |
| Azul Noturno | `#121A26` | painéis, cards, app bar |
| Dourado Forja | `#B88A3B` | marca, bordas ativas, botões principais |
| Ouro Claro | `#D6B36A` | ícones, highlights, detalhes |
| Pergaminho | `#E8DCC7` | texto claro e áreas de leitura |
| Verde de Ação | `#2FA36B` | confirmar, sucesso, ação positiva |

## Tipografia

- títulos/branding: **Cinzel**;
- interface e leitura: **Inter**.

No starter Flutter isso é aplicado via `google_fonts`, sem distribuir arquivos de fonte no pacote.

## Componentes

### Fundo
Gradiente muito discreto entre Preto Abissal e Azul Noturno. Nada de glow roxo global.

### Cards
- fundo `#121A26`;
- borda neutra escura;
- selecionado: borda Dourado Forja;
- sombra quente/dourada sutil, nunca neon roxo.

### Botão principal
Dourado Forja, texto escuro.

### Botão positivo
Verde de Ação.

### Texto
Pergaminho como texto principal. Branco puro apenas pontualmente.

## Fluxo de criação

A imagem `06_REFERENCIAS/referencia_fluxo_personagem.jpeg` é referência de UX:
- entrada/boas-vindas;
- seleção de classe;
- seleção de raça/origem;
- identidade/aparência;
- equipamento/estilo;
- nome e resumo;
- personagem criado.

O layout pode seguir essa cadência, mas toda a cor púrpura deve ser substituída pela identidade acima.

## Marca
Use prioritariamente:
- `assets/forja-symbol-oficial-512.webp`
- `assets/forja-logo-1024.webp`

Não redesenhar o símbolo.
