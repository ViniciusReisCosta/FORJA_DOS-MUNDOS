import 'package:flutter/material.dart';

/// Paleta do GUIA_IDENTIDADE.md enviado pelo proprietário da marca.
abstract final class ForjaColors {
  static const abyss = Color(0xFF0B0E14);
  static const night = Color(0xFF121A26);
  static const forgeGold = Color(0xFFB88A3B);
  static const lightGold = Color(0xFFD6B36A);
  static const parchment = Color(0xFFE8DCC7);
  static const actionGreen = Color(0xFF2FA36B);
  static const danger = Color(0xFFB83B36);
  static const muted = Color(0xFF9C968B);
  static const border = Color(0xFF2A3442);
  static const selected = Color(0xFF242219);
}

ThemeData buildForjaTheme() {
  final base = ThemeData.dark(useMaterial3: true);
  final text = base.textTheme.apply(
    fontFamily: 'Inter',
    bodyColor: ForjaColors.parchment,
    displayColor: ForjaColors.parchment,
  );
  const heading = TextStyle(
    fontFamily: 'Cinzel',
    color: ForjaColors.lightGold,
    fontWeight: FontWeight.w700,
  );
  return base.copyWith(
    scaffoldBackgroundColor: ForjaColors.abyss,
    colorScheme: const ColorScheme.dark(
      primary: ForjaColors.forgeGold,
      onPrimary: ForjaColors.abyss,
      secondary: ForjaColors.lightGold,
      onSecondary: ForjaColors.abyss,
      surface: ForjaColors.night,
      onSurface: ForjaColors.parchment,
      error: ForjaColors.danger,
      onError: ForjaColors.parchment,
      outline: ForjaColors.border,
      surfaceTint: Colors.transparent,
    ),
    textTheme: text.copyWith(
      headlineLarge: heading.copyWith(fontSize: 30),
      headlineMedium: heading.copyWith(fontSize: 24),
      titleLarge: heading.copyWith(fontSize: 20),
    ),
    appBarTheme: const AppBarTheme(
      backgroundColor: ForjaColors.abyss,
      foregroundColor: ForjaColors.parchment,
      surfaceTintColor: Colors.transparent,
      elevation: 0,
      centerTitle: true,
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: ForjaColors.forgeGold,
        foregroundColor: ForjaColors.abyss,
        minimumSize: const Size(48, 52),
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: const TextStyle(
          fontFamily: 'Inter', fontWeight: FontWeight.w700, letterSpacing: 1,
        ),
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: ForjaColors.parchment,
        side: const BorderSide(color: ForjaColors.border),
        minimumSize: const Size(48, 48),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    ),
    progressIndicatorTheme: const ProgressIndicatorThemeData(
      color: ForjaColors.forgeGold,
      linearTrackColor: ForjaColors.border,
    ),
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: ForjaColors.night,
      contentTextStyle: TextStyle(
        fontFamily: 'Inter', color: ForjaColors.parchment,
      ),
      behavior: SnackBarBehavior.floating,
    ),
  );
}
