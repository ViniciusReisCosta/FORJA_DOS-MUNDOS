import 'package:flutter/material.dart';
import '../theme/forja_theme.dart';

class ForjaBrand extends StatelessWidget {
  const ForjaBrand({super.key});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Image.asset(
          'assets/forja-symbol-oficial-512.webp',
          width: 32, height: 32, fit: BoxFit.contain,
          excludeFromSemantics: true,
        ),
        const SizedBox(width: 8),
        const Flexible(
          child: Text(
            'FORJA DOS MUNDOS',
            style: TextStyle(
              fontFamily: 'Cinzel', fontSize: 12,
              fontWeight: FontWeight.w700, color: ForjaColors.lightGold,
              letterSpacing: 0.8,
            ),
          ),
        ),
      ],
    );
  }
}

class ForjaStep extends StatelessWidget {
  const ForjaStep({super.key, required this.step});
  final int step;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'ETAPA $step DE 3',
          style: const TextStyle(
            color: ForjaColors.muted, fontSize: 11, letterSpacing: 1.5,
          ),
        ),
        const SizedBox(height: 8),
        ClipRRect(
          borderRadius: BorderRadius.circular(4),
          child: LinearProgressIndicator(
            value: step / 3, minHeight: 4,
            semanticsLabel: 'Etapa $step de 3 do protótipo',
          ),
        ),
      ],
    );
  }
}
