import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'pages/aparencia_page.dart';
import 'theme/forja_theme.dart';
import 'widgets/forja_brand.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: ForjaColors.abyss,
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  runApp(const ForjaApp());
}

class ForjaApp extends StatelessWidget {
  const ForjaApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Forja dos Mundos',
      debugShowCheckedModeBanner: false,
      theme: buildForjaTheme(),
      builder: (context, child) => ColoredBox(
        color: ForjaColors.abyss,
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 600),
            child: child ?? const SizedBox.shrink(),
          ),
        ),
      ),
      home: const ForjaSplashPage(),
    );
  }
}

class ForjaSplashPage extends StatelessWidget {
  const ForjaSplashPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: DecoratedBox(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
            colors: [ForjaColors.night, ForjaColors.abyss],
          ),
        ),
        child: SafeArea(
          child: LayoutBuilder(
            builder: (context, constraints) => SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 24),
              child: ConstrainedBox(
                constraints: BoxConstraints(
                  minHeight: (constraints.maxHeight - 48).clamp(0.0, double.infinity).toDouble(),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Image.asset(
                      'assets/forja-logo-1024.webp',
                      width: 290, height: 290, fit: BoxFit.contain,
                      semanticLabel: 'Forja dos Mundos, símbolo oficial',
                    ),
                    const SizedBox(height: 24),
                    Text(
                      'CRIE SEU\nPERSONAGEM',
                      textAlign: TextAlign.center,
                      style: Theme.of(context).textTheme.headlineMedium,
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'Dê vida ao seu herói e comece sua jornada nos mundos da Forja.',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: ForjaColors.parchment, height: 1.6),
                    ),
                    const SizedBox(height: 28),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) => const CriacaoPersonagemPage(),
                          ),
                        ),
                        icon: const Icon(Icons.arrow_forward, size: 20),
                        label: const Text('COMEÇAR'),
                      ),
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('Tela de login em desenvolvimento.')),
                        ),
                        icon: const Icon(Icons.person_outline, color: ForjaColors.lightGold),
                        label: const Text('LOGIN'),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class CriacaoPersonagemPage extends StatefulWidget {
  const CriacaoPersonagemPage({super.key});

  @override
  State<CriacaoPersonagemPage> createState() => _CriacaoPersonagemPageState();
}

class _CriacaoPersonagemPageState extends State<CriacaoPersonagemPage> {
  String classeSelecionada = 'Guerreiro';

  static const classes = [
    (nome: 'Guerreiro', descricao: 'Força, resistência e combate corpo a corpo.', icone: Icons.shield_outlined),
    (nome: 'Mago', descricao: 'Domine a magia e os poderes elementais.', icone: Icons.auto_awesome_outlined),
    (nome: 'Arqueiro', descricao: 'Precisão, agilidade e ataques à distância.', icone: Icons.gps_fixed),
    (nome: 'Sacerdote', descricao: 'Cura, suporte e proteção dos aliados.', icone: Icons.health_and_safety_outlined),
    (nome: 'Ladino', descricao: 'Velocidade, furtividade e estratégia.', icone: Icons.visibility_off_outlined),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const ForjaBrand()),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 8),
                children: [
                  const ForjaStep(step: 1),
                  const SizedBox(height: 24),
                  Text('ESCOLHA SUA CLASSE', style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 10),
                  const Text(
                    'Cada herói possui habilidades únicas. Qual será o seu caminho?',
                    style: TextStyle(color: ForjaColors.muted, height: 1.5),
                  ),
                  const SizedBox(height: 24),
                  for (final item in classes)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: Semantics(
                        selected: classeSelecionada == item.nome,
                        child: Material(
                          color: classeSelecionada == item.nome ? ForjaColors.selected : ForjaColors.night,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(14),
                            side: BorderSide(
                              color: classeSelecionada == item.nome ? ForjaColors.forgeGold : ForjaColors.border,
                              width: classeSelecionada == item.nome ? 1.5 : 1,
                            ),
                          ),
                          clipBehavior: Clip.antiAlias,
                          child: InkWell(
                            onTap: () => setState(() => classeSelecionada = item.nome),
                            child: Padding(
                              padding: const EdgeInsets.all(16),
                              child: Row(
                                children: [
                                  Icon(item.icone, color: ForjaColors.lightGold, size: 28),
                                  const SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(item.nome, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700)),
                                        const SizedBox(height: 5),
                                        Text(item.descricao, style: const TextStyle(color: ForjaColors.muted, fontSize: 12, height: 1.4)),
                                      ],
                                    ),
                                  ),
                                  if (classeSelecionada == item.nome) ...[
                                    const SizedBox(width: 8),
                                    const Icon(Icons.check_circle, color: ForjaColors.lightGold, size: 20),
                                  ],
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute<void>(builder: (_) => const EscolhaGeneroPage()),
                  ),
                  child: const Text('PRÓXIMO  ›'),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
