import 'package:flutter/material.dart';
import '../theme/forja_theme.dart';
import '../widgets/forja_brand.dart';
import 'personalizacao.dart';

class EscolhaGeneroPage extends StatefulWidget {
  const EscolhaGeneroPage({super.key});

  @override
  State<EscolhaGeneroPage> createState() => _EscolhaGeneroPageState();
}

class _EscolhaGeneroPageState extends State<EscolhaGeneroPage> {
  String generoSelecionado = 'Masculino';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const ForjaBrand()),
      body: SafeArea(
        top: false,
        child: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
                children: [
                  const ForjaStep(step: 2),
                  const SizedBox(height: 24),
                  Text('ESCOLHA SEU GÊNERO', style: Theme.of(context).textTheme.headlineMedium),
                  const SizedBox(height: 10),
                  const Text(
                    'Esta escolha não limita sua experiência de jogo.',
                    style: TextStyle(color: ForjaColors.muted, height: 1.5),
                  ),
                  const SizedBox(height: 24),
                  LayoutBuilder(
                    builder: (context, constraints) => Wrap(
                      spacing: 14,
                      runSpacing: 14,
                      children: [
                        for (final nome in ['Masculino', 'Feminino'])
                          SizedBox(
                            width: constraints.maxWidth < 300
                                ? constraints.maxWidth
                                : (constraints.maxWidth - 14) / 2,
                            child: _cartaoGenero(nome),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(24, 12, 24, 16),
              child: Row(
                children: [
                  Expanded(child: OutlinedButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text('VOLTAR'),
                  )),
                  const SizedBox(width: 14),
                  Expanded(child: ElevatedButton(
                    onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(builder: (_) => const AparenciaScreen()),
                    ),
                    child: const Text('PRÓXIMO ›'),
                  )),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _cartaoGenero(String nome) {
    final selecionado = generoSelecionado == nome;
    return Semantics(
      selected: selecionado,
      child: Material(
        color: selecionado ? ForjaColors.selected : ForjaColors.night,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
          side: BorderSide(
            color: selecionado ? ForjaColors.forgeGold : ForjaColors.border,
            width: selecionado ? 1.5 : 1,
          ),
        ),
        clipBehavior: Clip.antiAlias,
        child: InkWell(
          onTap: () => setState(() => generoSelecionado = nome),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              children: [
                Align(
                  alignment: Alignment.topRight,
                  child: Icon(
                    selecionado ? Icons.check_circle : Icons.radio_button_unchecked,
                    size: 20,
                    color: selecionado ? ForjaColors.lightGold : ForjaColors.muted,
                  ),
                ),
                const SizedBox(height: 20),
                Icon(
                  nome == 'Masculino' ? Icons.man : Icons.woman,
                  size: 80, color: ForjaColors.lightGold,
                ),
                const SizedBox(height: 20),
                Text(nome, style: const TextStyle(fontWeight: FontWeight.w700)),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
