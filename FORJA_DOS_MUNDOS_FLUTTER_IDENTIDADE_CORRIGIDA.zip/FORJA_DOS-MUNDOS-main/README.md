# Forja dos Mundos — Flutter com identidade oficial

Projeto `FORJA_DOS-MUNDOS-main` atualizado com o guia e os recursos oficiais do pacote `FORJA_FLUTTER_HANDOFF_LOGIN_FICHA_IDENTIDADE_v1`.

## O que mudou

- Abertura reconstruída com componentes Flutter, logotipo oficial completo e botões visíveis. A antiga imagem com interface e barra de status desenhadas não é mais usada.
- Tema central em `lib/theme/forja_theme.dart`: Preto Abissal `#0B0E14`, Azul Noturno `#121A26`, Dourado Forja `#B88A3B`, Ouro Claro `#D6B36A`, Pergaminho `#E8DCC7` e Verde de Ação `#2FA36B`.
- Botões principais dourados com texto escuro, seleções e progresso dourados, painéis azul-noturno e textos claros em pergaminho. Verde fica disponível para ações futuras de confirmação/sucesso.
- Símbolo oficial nos cabeçalhos. A energia azul/vermelha é preservada na arte oficial, sem redesenhar ou recolorir o logotipo.
- Fontes locais Cinzel e Inter, com licenças OFL incluídas. Nenhum download de fontes em tempo de execução e nenhuma dependência Flutter nova.
- Classe e gênero com conteúdo rolável; abertura ajustada para telas baixas; largura limitada a 600 pixels em telas grandes.
- Barra do sistema, início Android/iOS e fundo de carregamento web em preto.
- Referências a retratos e miniaturas inexistentes substituídas por ícones deliberados. Os desenhos de prévia do projeto original continuam sendo protótipos.
- Teste padrão que usava a classe inexistente `MyApp` substituído por testes do fluxo real.

## Executar

Abra esta pasta como projeto Flutter. O requisito Dart `^3.13.4` e as dependências originais foram mantidos.

```bash
flutter pub get
flutter analyze
flutter test
flutter run
```

Para Android, depois de configurar o SDK Android:

```bash
flutter build apk --release
```

O ZIP contém código-fonte, não um APK compilado. Caso o checkout não contenha os arquivos locais de inicialização do Gradle, execute `flutter create --platforms=android .` e revise os arquivos de plataforma gerados antes de compilar. O arquivo original já não continha `gradlew` nem `gradle-wrapper.jar`.

## Estado real e referência futura

O aplicativo recebido tem três telas de criação: classe, gênero e aparência. O indicador agora mostra essas três etapas existentes, em vez de anunciar cinco etapas incompletas.

A imagem enviada continua sendo uma referência futura de fluxo/composição. As próximas partes ainda precisam ser implementadas: raça/origem, equipamentos, nome/resumo, confirmação, armazenamento e entrada no mundo. Login continua exibindo o aviso de desenvolvimento do projeto original. A aparência ainda usa desenhos simples; os estilos de cabelo selecionam um estado visual de interface, mas ainda não mudam o corte na prévia. Classe e gênero ainda não são transportados para uma ficha persistida. Os ícones de instalação dos sistemas continuam sendo os do projeto recebido.

O starter do proprietário foi usado como referência de identidade. Sua autenticação, banco e telas de ficha não foram misturados a este protótipo nesta alteração visual.

## Validação desta entrega

- Sintaxe Dart conferida com parser Tree-sitter.
- Referências a assets e fontes conferidas contra os arquivos reais.
- Fontes e arquivos XML/JSON/YAML conferidos localmente.
- Testes Flutter preparados para navegação, seleção de classe, aviso de login e tela pequena.
- Flutter/Dart SDK não estão instalados no ambiente de edição: `flutter analyze`, `flutter test`, renderização nativa e compilação do APK não foram executados. Execute os comandos acima no ambiente Flutter do desenvolvedor antes de publicar.

## Manutenção da identidade

Novas telas devem importar `lib/theme/forja_theme.dart`. Use `ForjaColors` em vez de repetir cores hexadecimais e use `ForjaBrand` no cabeçalho. As cores de pele, cabelo e olhos são opções do personagem; não são a paleta da interface.

A imagem antiga `assets/forja_splash.png` foi mantida apenas como histórico do material recebido; não está declarada no bundle nem é exibida.
